val scala3Version = "3.6.3"

lazy val root = project
  .in(file("."))
  .enablePlugins(JmhPlugin)
  .settings(
    name := "staged-scala",
    version := "0.1.0-SNAPSHOT",

    scalaVersion := scala3Version,

    libraryDependencies += "org.scalameta" %% "munit" % "1.0.0" % Test,

    libraryDependencies += "org.scalacheck" %% "scalacheck" % "1.17.0",

    javaOptions += "-Xss200m",
    javaOptions += "-Xmx8g"

  )
